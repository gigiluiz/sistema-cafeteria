# Sistema para Coffee Shops Tia Rosa

# Listas para armazenar dados
produtos = []
clientes = []
pedidos = []

def cadastrar_produto():
    print("\n--- Cadastro de Produto ---")
    nome = input("Nome do produto: ")
    preco = float(input("Preço: "))
    ingredientes = input("Ingredientes: ")

    produto = {
        'nome': nome,
        'preco': preco,
        'ingredientes': ingredientes
    }

    produtos.append(produto)
    print("\u2705 Produto cadastrado com sucesso!")

def listar_produtos():
    print("\n--- Lista de Produtos ---")
    for i, p in enumerate(produtos):
        print(f"{i+1}. {p['nome']} - R${p['preco']:.2f}")
        print(f"   Ingredientes: {p['ingredientes']}")

def cadastrar_cliente():
    print("\n--- Cadastro de Cliente ---")
    nome = input("Nome do cliente: ")
    telefone = input("Telefone: ")

    cliente = {
        'nome': nome,
        'telefone': telefone
    }

    clientes.append(cliente)
    print("\u2705 Cliente cadastrado com sucesso!")

def fazer_pedido():
    print("\n--- Realizar Pedido ---")
    cliente_nome = input("Nome do cliente: ")

    cliente = next((c for c in clientes if c['nome'] == cliente_nome), None)
    if not cliente:
        print("\u26a0\ufe0f Cliente não encontrado! Cadastre antes.")
        return

    listar_produtos()
    pedido = []

    while True:
        opcao = input("Digite o número do produto (ou 'fim' para encerrar): ")
        if opcao.lower() == 'fim':
            break
        try:
            index = int(opcao) - 1
            pedido.append(produtos[index])
        except:
            print("❌ Produto inválido!")

    pedidos.append({'cliente': cliente, 'itens': pedido})
    print("\u2705 Pedido realizado com sucesso!")

def exibir_pedidos():
    print("\n--- Pedidos Realizados ---")
    for p in pedidos:
        print(f"Cliente: {p['cliente']['nome']}")
        total = 0
        for item in p['itens']:
            print(f" - {item['nome']} R${item['preco']:.2f}")
            total += item['preco']
        print(f"Total do pedido: R${total:.2f}\n")

# Menu principal
while True:
    print("\n===== MENU =====")
    print("1. Cadastrar Produto")
    print("2. Cadastrar Cliente")
    print("3. Fazer Pedido")
    print("4. Exibir Pedidos")
    print("5. Sair")

    escolha = input("Escolha uma opção: ")

    if escolha == '1':
        cadastrar_produto()
    elif escolha == '2':
        cadastrar_cliente()
    elif escolha == '3':
        fazer_pedido()
    elif escolha == '4':
        exibir_pedidos()
    elif escolha == '5':
        print("Saindo... ☕ Até logo!")
        break
    else:
        print("Opção inválida.")

